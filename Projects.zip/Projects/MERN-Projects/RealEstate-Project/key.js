import randomstring from "randomstring";

var s = randomstring.generate();
console.log(s);