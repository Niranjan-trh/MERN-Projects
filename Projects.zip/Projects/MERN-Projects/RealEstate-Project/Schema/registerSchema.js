// Require Mongoose
import mongoose from 'mongoose';
import uniqueValidator from 'mongoose-unique-validator';
 
const registerSchema = mongoose.Schema({
  _id: Number,
  name: {
    type: String,
    required: [true,"Name is required"],
    lowercase: true,
    trim: true,
  },
  email: {
    type: String,
    required: [true,"Username is required"],
    unique: true,
    lowercase: true,
    trim: true
  },
  password: {
    type: String,
    required: [true,"Password is required"],
    maxlength: 10,
    minlength:5,
    trim: true
  },
  mobile: {
    type: String,
    required: [true,"Mobile is required"],
    maxlength: 10,
    minlength:10,
    trim: true
  },
  message: {
    type: String,
    required: [true,"message is required"],
    trim: true
  },
  city: {
    type: String,
    required: [true,"City is required"],
    trim: true
  },
  gender: {
    type: String,
    required: [true,"Gender is required"],
  },
  role: String,
  status: Number,
  info: String
});

// Apply the uniqueValidator plugin to RegisterSchema.
registerSchema.plugin(uniqueValidator);

// compile schema to model
const registerSchemaModel = mongoose.model('reg_tmp', registerSchema ,'register');

export default registerSchemaModel




/*
mongoose-unique-validator
-------------------------
mongoose-unique-validator is a plugin which adds pre-save validation for unique fields within a Mongoose schema. This makes error handling much easier, since you will get a Mongoose validation error when you attempt to violate a unique constraint, rather than an E11000 error from MongoDB.

Mongoose
--------
Mongoose is a JavaScript object-oriented programming library that creates a connection between MongoDB and the Node.js JavaScript runtime environment
*/